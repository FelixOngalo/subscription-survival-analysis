# Generate the raw subscription extract (with data-quality problems) and the
# hidden ground truth used only to GRADE the analysis afterwards.
source("R/survival_functions.R")
library(readr)

sim <- simulate_subscriptions(n = 6000, seed = 2026, non_ph = FALSE, messy = TRUE)
write_csv(sim$raw, "data/raw/subscriptions_raw.csv")
saveRDS(sim$truth, "data/clean/truth_latent_tenure.rds")      # never used for modelling

# A second extract in which Premium churn has a different shape (non-proportional hazards),
# used in 03_cox_model.R to show what a violated assumption looks like.
sim_nonph <- simulate_subscriptions(n = 6000, seed = 7, non_ph = TRUE, messy = FALSE)
write_csv(sim_nonph$raw, "data/raw/subscriptions_nonph_raw.csv")

cat("Raw rows:", nrow(sim$raw), "\n")
