source("R/survival_functions.R")
library(readr)

raw <- read_csv("data/raw/subscriptions_raw.csv", show_col_types = FALSE)
cleaned <- clean_subscriptions(raw)
print(cleaned$log)

d <- cleaned$data
cat("\nCancelled:", sum(d$event), " (", round(100 * mean(d$event), 1), "% of customers), still active (censored):", sum(1 - d$event), "\n")
cat("Follow-up range (months):", round(min(d$tenure_months), 1), "to", round(max(d$tenure_months), 1), "\n")
stopifnot(!anyDuplicated(d$customer_id), all(d$tenure_months > 0), all(levels(d$plan) %in% unique(as.character(d$plan))))

saveRDS(list(data = d, log = cleaned$log), "data/clean/subscriptions.rds")
