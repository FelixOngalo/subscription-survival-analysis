source("R/survival_functions.R")
library(tidyr)
set.seed(1)

obj <- readRDS("data/clean/subscriptions.rds"); d <- obj$data
truth <- readRDS("data/clean/truth_latent_tenure.rds")
d <- left_join(d, select(truth, customer_id, true_tenure_months), by = "customer_id")

# ---- 1. Why naive tenure statistics mislead --------------------------------
cat("=== Naive versus survival-aware estimates ===\n")
mature <- d |> filter(signup_date <= SNAPSHOT - round(12 * DAYS_PER_MONTH))   # everyone observable for a full year
km_all <- km_retention(d, times = 12)
naive <- tibble(
  quantity = c("12-month cancellation rate", "Average tenure (months)"),
  naive_all_customers = c(mean(d$event == 1 & d$tenure_months <= 12), mean(d$tenure_months)),
  naive_churners_only = c(NA, mean(d$tenure_months[d$event == 1])),
  mature_cohort_only = c(mean(mature$event == 1 & mature$tenure_months <= 12), NA),
  kaplan_meier = c(1 - km_all$retention, km_overview(d, tau = 24)$rmst),
  truth = c(mean(d$true_tenure_months <= 12), mean(pmin(d$true_tenure_months, 24))))
print(naive)
cat("(Average tenure row: Kaplan-Meier column is the restricted mean up to 24 months, and the truth column is the true mean of min(T, 24).)\n")

# ---- 2. Kaplan-Meier retention ------------------------------------------
overall <- list(overview = km_overview(d), retention = km_retention(d))
print(overall$overview); print(overall$retention)

groups <- c("plan", "channel", "country")
by_group <- lapply(groups, function(g) list(
  variable = g,
  overview = km_overview(d, g),
  retention = km_retention(d, g),
  logrank = logrank_p(d, g)))
names(by_group) <- groups
for (g in groups) { cat("\n--", g, "log-rank p =", signif(by_group[[g]]$logrank["p"], 3), "\n"); print(by_group[[g]]$overview) }

# ---- 3. Does KM recover the truth? (retention by plan) ----------------
truth_by_plan <- d |> group_by(group = plan) |>
  summarise(true_12m = mean(true_tenure_months > 12), true_24m = mean(true_tenure_months > 24), .groups = "drop") |>
  mutate(group = as.character(group))
km_plan <- by_group$plan$retention |> filter(months %in% c(12, 24)) |>
  select(group, months, retention, lower, upper) |>
  mutate(truth = ifelse(months == 12, truth_by_plan$true_12m[match(group, truth_by_plan$group)],
                        truth_by_plan$true_24m[match(group, truth_by_plan$group)]),
         ci_covers_truth = lower <= truth & truth <= upper)
print(km_plan)

# ---- 4. Cohort retention by signup quarter ---------------------------
d$signup_quarter <- paste0(format(d$signup_date, "%Y"), "-Q", ceiling(as.integer(format(d$signup_date, "%m")) / 3))
cohorts <- km_retention(d, "signup_quarter", times = c(3, 6, 12)) |>
  left_join(count(d, group = signup_quarter, name = "customers"), by = "group")
# keep only (cohort, month) cells that have been fully observable
cohort_ends <- d |> group_by(group = signup_quarter) |> summarise(latest_signup = max(signup_date), .groups = "drop")
cohorts <- cohorts |> left_join(cohort_ends, by = "group") |>
  mutate(observable = latest_signup + round(months * DAYS_PER_MONTH) <= SNAPSHOT)
cohort_table <- cohorts |> filter(observable) |> select(group, customers, months, retention) |>
  pivot_wider(names_from = months, values_from = retention, names_prefix = "month_")
print(cohort_table)

# A trap: the plain share of customers who cancelled falls for recent cohorts only because
# they have had less time to cancel. The Kaplan-Meier 6-month cancellation rate is comparable across cohorts.
cohort_naive <- d |> group_by(group = signup_quarter) |>
  summarise(customers = n(), naive_share_cancelled = mean(event), .groups = "drop") |>
  left_join(cohorts |> filter(months == 6, observable) |> transmute(group, km_6m_cancellation = 1 - retention), by = "group")
print(cohort_naive)

# ---- 5. Curves for plotting ---------------------------------------------
curves <- list(plan = km_curves(d, "plan"), channel = km_curves(d, "channel"), overall = km_curves(mutate(d, all = "All"), "all"))

saveRDS(list(naive = naive, overall = overall, by_group = by_group, km_plan = km_plan,
             cohort_table = cohort_table, cohort_naive = cohort_naive, curves = curves, n = nrow(d), events = sum(d$event)),
        "data/clean/km_results.rds")
