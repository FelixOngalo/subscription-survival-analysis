source("R/survival_functions.R")
set.seed(4)

d <- readRDS("data/clean/subscriptions.rds")$data
fit <- readRDS("data/clean/cox_fit.rds")
km <- readRDS("data/clean/km_results.rds")
TAU <- 24                                    # value horizon in months (all signups are observed to ~24+ months for the earliest cohorts)
grid <- 0:TAU
trapz <- function(s) sum((s[-1] + s[-length(s)]) / 2)          # area under a curve on a monthly grid

# ---- 1. Customer value by plan (Kaplan-Meier, 24-month horizon) --------
plan_value <- km_overview(d, "plan", tau = TAU) |>
  mutate(price = unname(PRICE[group]), expected_paid_months = rmst, value_24m = price * expected_paid_months)
print(plan_value)

# ---- 2. Predicted retention for example customers, versus the truth ----
profiles <- tibble(
  profile = c("Basic, paid ad, typical usage", "Standard, organic, typical usage", "Premium, referral, heavy user"),
  plan = c("Basic", "Standard", "Premium"), channel = c("paid", "organic", "referral"), usage_z = c(0, 0, 1))
newdata <- profiles |> mutate(plan = factor(plan, levels(d$plan)), channel = factor(channel, levels(d$channel)),
                              country = factor("Kenya", levels(d$country)))
sf <- survfit(fit, newdata = newdata)
pred <- summary(sf, times = grid, extend = TRUE)$surv           # (TAU + 1) x 3 matrix
profile_table <- bind_rows(lapply(seq_len(nrow(profiles)), function(i) {
  truth_curve <- true_survival(grid, profiles$plan[i], profiles$channel[i], profiles$usage_z[i])
  tibble(profile = profiles$profile[i],
         model_12m = pred[grid == 12, i], true_12m = truth_curve[grid == 12],
         model_expected_months_24 = trapz(pred[, i]), true_expected_months_24 = trapz(truth_curve),
         price = unname(PRICE[profiles$plan[i]]))
})) |> mutate(model_value_24m = price * model_expected_months_24, true_value_24m = price * true_expected_months_24)
print(profile_table)
profile_curves <- bind_rows(lapply(seq_len(nrow(profiles)), function(i)
  tibble(profile = profiles$profile[i], months = grid, model = pred[, i],
         truth = true_survival(grid, profiles$plan[i], profiles$channel[i], profiles$usage_z[i]))))

# ---- 3. What-if: acquire everyone through paid ads, or through referrals? -----
# Standardisation (g-formula): keep each customer's own plan, usage and country,
# set the channel for everybody, predict each customer's curve, and average the curves.
sub <- d[sample.int(nrow(d), 500), ]
scenario_curve <- function(ch_set) {
  nd <- mutate(sub, channel = factor(ch_set, levels(d$channel)))
  s <- summary(survfit(fit, newdata = nd), times = grid, extend = TRUE)$surv
  list(model = rowMeans(s),
       truth = rowMeans(vapply(seq_len(nrow(sub)), function(i) true_survival(grid, as.character(sub$plan[i]), ch_set, sub$usage_z[i]), numeric(length(grid)))))
}
channels <- c("paid", "organic", "referral")
scen <- lapply(setNames(channels, channels), scenario_curve)
avg_price <- mean(PRICE[as.character(sub$plan)])
scenario_table <- bind_rows(lapply(channels, function(ch) tibble(
  channel = ch,
  model_12m = scen[[ch]]$model[grid == 12], true_12m = scen[[ch]]$truth[grid == 12],
  model_months_24 = trapz(scen[[ch]]$model), true_months_24 = trapz(scen[[ch]]$truth),
  model_value_per_customer = avg_price * trapz(scen[[ch]]$model),
  true_value_per_customer = avg_price * trapz(scen[[ch]]$truth))))
print(scenario_table)
scenario_curves <- bind_rows(lapply(channels, function(ch) tibble(channel = ch, months = grid, model = scen[[ch]]$model, truth = scen[[ch]]$truth)))

# Break-even acquisition cost: how much more could referral acquisition cost than paid ads?
extra_value <- scenario_table$model_value_per_customer[scenario_table$channel == "referral"] -
               scenario_table$model_value_per_customer[scenario_table$channel == "paid"]
cat("\nModel-estimated extra 24-month revenue per referred (vs paid) customer:", round(extra_value, 2), "\n")

saveRDS(list(plan_value = plan_value, profile_table = profile_table, profile_curves = profile_curves,
             scenario_table = scenario_table, scenario_curves = scenario_curves, extra_value = extra_value, tau = TAU),
        "data/clean/business_results.rds")
