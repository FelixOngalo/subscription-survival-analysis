source("R/survival_functions.R")
library(tidyr)
library(readr)
set.seed(3)

d <- readRDS("data/clean/subscriptions.rds")$data

# ---- 1. Multivariable Cox model ---------------------------------------
fit <- coxph(COX_FORMULA, data = d, ties = "efron")
hr <- cox_vs_truth(fit)
print(hr, n = 20)
cat("Concordance:", round(summary(fit)$concordance[1], 3), "\n")
cat("Share of 95% CIs covering the true hazard ratio:", round(mean(hr$ci_covers_truth), 2), "\n")

# ---- 2. Proportional-hazards diagnostics ---------------------
zph <- cox.zph(fit)
zph_table <- as.data.frame(zph$table) |> tibble::rownames_to_column("term") |> as_tibble()
print(zph_table)

# ---- 3. When proportional hazards FAILS: Premium churn has a different shape ----
raw2 <- read_csv("data/raw/subscriptions_nonph_raw.csv", show_col_types = FALSE)
d2 <- clean_subscriptions(raw2)$data
fit2 <- coxph(COX_FORMULA, data = d2)
zph2 <- cox.zph(fit2)
zph2_table <- as.data.frame(zph2$table) |> tibble::rownames_to_column("term") |> as_tibble()
print(zph2_table)

# Let the plan effects differ before and after month 12 (split follow-up at 12 months).
split <- survSplit(Surv(tenure_months, event) ~ ., data = d2, cut = 12, episode = "period")
split <- split |> mutate(
  standard_early = plan == "Standard" & period == 1, standard_late = plan == "Standard" & period == 2,
  premium_early  = plan == "Premium"  & period == 1, premium_late  = plan == "Premium"  & period == 2)
fit_split <- coxph(Surv(tstart, tenure_months, event) ~ standard_early + standard_late + premium_early + premium_late +
                     channel + country + usage_z, data = split)
split_hr <- broom::tidy(fit_split, exponentiate = TRUE, conf.int = TRUE) |>
  filter(grepl("early|late", term)) |> select(term, hazard_ratio = estimate, conf.low, conf.high)
print(split_hr)

# ---- 4. How reliable is the Cox model? 100 repeated simulations --------
reps <- 100
one_rep <- function(i) {
  s <- simulate_subscriptions(n = 3000, seed = 1000 + i, messy = FALSE)
  dd <- clean_subscriptions(s$raw)$data
  broom::tidy(coxph(COX_FORMULA, data = dd), conf.int = TRUE) |>
    mutate(rep = i, true_beta = unname(TRUE_BETA[term]), covered = conf.low <= true_beta & true_beta <= conf.high)
}
sims <- bind_rows(lapply(seq_len(reps), one_rep))
coverage <- sims |> group_by(term) |>
  summarise(true_beta = first(true_beta), mean_estimate = mean(estimate), bias = mean(estimate) - first(true_beta),
            empirical_sd = sd(estimate), mean_reported_se = mean(std.error), coverage_95 = mean(covered), .groups = "drop")
print(coverage)

saveRDS(list(hr = hr, concordance = unname(summary(fit)$concordance[1]), zph_table = zph_table,
             zph2_table = zph2_table, split_hr = split_hr, coverage = coverage, reps = reps,
             n = nrow(d), events = sum(d$event)),
        "data/clean/cox_results.rds")
saveRDS(fit, "data/clean/cox_fit.rds")
