# Reusable functions for the subscription survival analysis:
# a simulator with KNOWN ground truth, cleaning, Kaplan-Meier helpers,
# Cox-model helpers and the true survival function used for grading.

library(dplyr)
library(tibble)
library(survival)
library(broom)

SNAPSHOT <- as.Date("2025-06-30")             # date the data were extracted
DAYS_PER_MONTH <- 30.4375
PRICE <- c(Basic = 9.99, Standard = 19.99, Premium = 39.99)

# True log hazard ratios used to generate the data (Weibull proportional hazards).
# Reference levels: plan = Basic, channel = organic, country = Kenya.
# usage_z is log(monthly logins) standardised as (log(logins) - 2.5) / 0.5,
# so one unit is a 65% increase in logins. Country has NO effect (a null variable).
TRUE_BETA <- c(planStandard = -0.3, planPremium = -0.6,
               channelpaid = 0.4, channelreferral = -0.4,
               countryUganda = 0, countryTanzania = 0, countryRwanda = 0, countryOther = 0,
               usage_z = -0.5)
BASE_LAMBDA <- 0.02       # baseline hazard scale (per month^k)
BASE_SHAPE  <- 1.3        # Weibull shape > 1: churn risk rises with tenure

#' Simulate a subscription business.
#' Tenure T ~ Weibull with hazard h(t | x) = lambda * k * t^(k-1) * exp(x'beta),
#' i.e. S(t | x) = exp(-lambda * t^k * exp(x'beta)).
#' Customers are observed until SNAPSHOT: those still active are right-censored.
#' @param non_ph if TRUE, Premium customers get a different Weibull shape (0.8),
#'   which breaks proportional hazards on purpose.
#' @param messy if TRUE, the raw table gets realistic data-quality problems.
#' @return list(raw = the table an analyst would receive, truth = latent true tenure).
simulate_subscriptions <- function(n = 6000, seed = 1, non_ph = FALSE, messy = TRUE) {
  set.seed(seed)
  plan    <- sample(c("Basic", "Standard", "Premium"), n, TRUE, prob = c(.50, .35, .15))
  channel <- sample(c("organic", "paid", "referral"), n, TRUE, prob = c(.40, .40, .20))
  country <- sample(c("Kenya", "Uganda", "Tanzania", "Rwanda", "Other"), n, TRUE, prob = c(.40, .20, .20, .10, .10))
  logins  <- pmax(1, round(exp(rnorm(n, 2.5, 0.5))))
  usage_z <- (log(logins) - 2.5) / 0.5

  lp <- TRUE_BETA[["planStandard"]] * (plan == "Standard") + TRUE_BETA[["planPremium"]] * (plan == "Premium") +
    TRUE_BETA[["channelpaid"]] * (channel == "paid") + TRUE_BETA[["channelreferral"]] * (channel == "referral") +
    TRUE_BETA[["usage_z"]] * usage_z
  k <- rep(BASE_SHAPE, n)
  if (non_ph) k[plan == "Premium"] <- 0.8
  t_true <- (-log(runif(n)) / (BASE_LAMBDA * exp(lp)))^(1 / k)      # months

  signup <- as.Date("2023-01-01") + sample(0:729, n, TRUE)
  cancel <- signup + round(t_true * DAYS_PER_MONTH)
  cancel[cancel > SNAPSHOT] <- NA                                    # still active: censored

  raw <- tibble(customer_id = sprintf("C%05d", seq_len(n)), signup_date = signup, cancel_date = cancel,
                plan = plan, channel = channel, country = country,
                monthly_logins = logins, monthly_price = unname(PRICE[plan]))
  truth <- tibble(customer_id = raw$customer_id, true_tenure_months = t_true, usage_z = usage_z)

  if (messy) {
    pick <- function(p) which(runif(n) < p)
    i <- pick(.08); raw$plan[i] <- ifelse(runif(length(i)) < .5, toupper(raw$plan[i]), paste0(" ", tolower(raw$plan[i])))
    i <- pick(.06); raw$channel[i] <- ifelse(runif(length(i)) < .5, toupper(raw$channel[i]), paste0(raw$channel[i], " "))
    raw$country[pick(.01)] <- ""
    raw$monthly_logins[pick(.015)] <- NA
    i <- pick(.003); raw$cancel_date[i] <- raw$signup_date[i] - sample(1:30, length(i), TRUE)   # impossible dates
    raw <- bind_rows(raw, raw[sample.int(n, round(.02 * n)), ])                              # exact duplicates
  }
  list(raw = raw, truth = truth)
}

#' Clean the raw table and build the survival variables.
#' tenure_months = time from signup to cancellation (event = 1) or to SNAPSHOT (event = 0).
#' @return list(data = clean tibble, log = tibble of what was fixed or removed)
clean_subscriptions <- function(raw, snapshot = SNAPSHOT) {
  n0 <- nrow(raw)
  x <- raw |>
    mutate(plan = tools::toTitleCase(tolower(trimws(plan))),
           channel = tolower(trimws(channel)),
           country = trimws(country))
  n_blank_country <- sum(x$country == "" | is.na(x$country))
  x <- x |> mutate(country = ifelse(country == "" | is.na(country), "Other", country))

  x <- distinct(x, customer_id, .keep_all = TRUE)
  n1 <- nrow(x)
  bad <- !is.na(x$cancel_date) & x$cancel_date < x$signup_date
  x <- x[!bad, ]
  n_missing_logins <- sum(is.na(x$monthly_logins))
  med <- median(x$monthly_logins, na.rm = TRUE)
  x <- x |>
    mutate(logins_imputed = is.na(monthly_logins),
           monthly_logins = ifelse(is.na(monthly_logins), med, monthly_logins),
           usage_z = (log(monthly_logins) - 2.5) / 0.5,
           event = as.integer(!is.na(cancel_date)),
           end_date = dplyr::coalesce(cancel_date, snapshot),
           tenure_months = pmax(as.numeric(end_date - signup_date), 0.5) / DAYS_PER_MONTH,
           plan = factor(plan, levels = c("Basic", "Standard", "Premium")),
           channel = factor(channel, levels = c("organic", "paid", "referral")),
           country = factor(country, levels = c("Kenya", "Uganda", "Tanzania", "Rwanda", "Other")))

  log <- tibble(step = c("Rows received", "Exact duplicate customers removed", "Cancel date before signup removed",
                         "Blank country recoded to Other", "Missing logins imputed (median)", "Rows analysed"),
                rows = c(n0, n0 - n1, sum(bad), n_blank_country, n_missing_logins, nrow(x)))
  list(data = x, log = log)
}

#' The TRUE survival probability S(t | x) of the generating model (PH case).
true_survival <- function(t, plan, channel, usage_z) {
  lp <- TRUE_BETA[["planStandard"]] * (plan == "Standard") + TRUE_BETA[["planPremium"]] * (plan == "Premium") +
    TRUE_BETA[["channelpaid"]] * (channel == "paid") + TRUE_BETA[["channelreferral"]] * (channel == "referral") +
    TRUE_BETA[["usage_z"]] * usage_z
  exp(-BASE_LAMBDA * t^BASE_SHAPE * exp(lp))
}

# ---- Kaplan-Meier helpers -------------------------------------------------

#' Restricted mean survival time: area under a step survival curve up to tau.
#' `time` are the curve's jump times (ascending) and `surv` the survival just after each.
rmst_from_curve <- function(time, surv, tau) {
  keep <- time < tau
  sum(c(1, surv[keep]) * diff(c(0, time[keep], tau)))
}

#' Overview per group: n, cancellations, median tenure, RMST up to tau.
km_overview <- function(data, group = NULL, tau = 24) {
  groups <- if (is.null(group)) list(All = data) else split(data, data[[group]])
  bind_rows(lapply(names(groups), function(g) {
    d <- groups[[g]]
    fit <- survfit(Surv(tenure_months, event) ~ 1, data = d)
    tibble(group = g, n = nrow(d), cancellations = sum(d$event),
           median_months = unname(summary(fit)$table["median"]),
           rmst = rmst_from_curve(fit$time, fit$surv, tau))
  }))
}

#' Retention (survival probability) with 95% CI at chosen months, per group.
km_retention <- function(data, group = NULL, times = c(3, 6, 12, 18, 24)) {
  groups <- if (is.null(group)) list(All = data) else split(data, data[[group]])
  bind_rows(lapply(names(groups), function(g) {
    fit <- survfit(Surv(tenure_months, event) ~ 1, data = groups[[g]])
    s <- summary(fit, times = times, extend = TRUE)
    tibble(group = g, months = times, retention = s$surv, lower = s$lower, upper = s$upper)
  }))
}

#' Tidy KM curves (one step function per group level), starting at (0, 1).
km_curves <- function(data, group) {
  fit <- survfit(as.formula(paste("Surv(tenure_months, event) ~", group)), data = data)
  out <- broom::tidy(fit)
  out$group <- if (is.null(out$strata)) "All" else sub("^.*=", "", out$strata)
  start <- tibble(time = 0, estimate = 1, conf.low = 1, conf.high = 1, group = unique(out$group))
  bind_rows(start, select(out, time, estimate, conf.low, conf.high, group))
}

#' Log-rank test p-value for a grouping variable.
logrank_p <- function(data, group) {
  sd <- survdiff(as.formula(paste("Surv(tenure_months, event) ~", group)), data = data)
  c(chisq = unname(sd$chisq), df = length(sd$n) - 1, p = 1 - pchisq(sd$chisq, length(sd$n) - 1))
}

# ---- Cox helpers ------------------------------------------------------

COX_FORMULA <- Surv(tenure_months, event) ~ plan + channel + country + usage_z

#' Hazard ratios with CIs next to the true values and a coverage flag.
cox_vs_truth <- function(fit) {
  broom::tidy(fit, exponentiate = TRUE, conf.int = TRUE) |>
    transmute(term, hazard_ratio = estimate, conf.low, conf.high, p.value,
              true_hr = unname(exp(TRUE_BETA[term])),
              ci_covers_truth = conf.low <= true_hr & true_hr <= conf.high)
}
